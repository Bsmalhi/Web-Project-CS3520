
import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author baljotmalhi
 */
public class DBUclass {
    private static Connection getConnection(){
        Connection conn= null;
        try{
            String url= "jdbc:mysql://localhost:3306/schema";
            String username= "root";
            String password = "Baljotmalhi1";
            class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(url, username, password);
        }catch(Exception e){
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
        return conn;
    }
        public List<User> getUsers(){
            
            Connection conn= getConnection();
            try{
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(" Select * from User");
                conn.close();
                
            }catch(Exception e){
                
            }
            return null;
        }
}
